import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Sidebar extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onTap;

  const Sidebar({super.key, required this.selectedIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 260,
      color: Colors.black.withOpacity(0.95),
      child: Column(
        children: [
          const SizedBox(height: 40),
          const Icon(Icons.car_rental, color: Colors.cyanAccent, size: 60),
          const SizedBox(height: 10),
          const Text(
            "ADMIN PANEL",
            style: TextStyle(
              color: Colors.cyanAccent,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 30),

          /// MENU UTAMA
          _menuItem(Icons.home, "Home", 0),
          _menuItem(Icons.directions_car, "Data Mobil", 1),
          _menuItem(Icons.book_online, "Booking", 2),
          _menuItem(Icons.bar_chart, "Reports", 3),

          /// PUSH KE BAWAH
          const Spacer(),

          /// LOGOUT
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.redAccent),
            title: const Text("Logout", style: TextStyle(color: Colors.white)),
            onTap: () async {
              await FirebaseAuth.instance.signOut();
              // AuthGate otomatis arahkan ke Login
            },
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _menuItem(IconData icon, String title, int index) {
    return InkWell(
      onTap: () => onTap(index),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selectedIndex == index
              ? Colors.cyanAccent.withOpacity(0.2)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.cyanAccent),
            const SizedBox(width: 14),
            Text(title, style: const TextStyle(color: Colors.white)),
          ],
        ),
      ),
    );
  }
}
