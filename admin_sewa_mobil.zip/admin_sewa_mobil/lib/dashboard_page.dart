import 'package:flutter/material.dart';
import 'sidebar.dart';
import 'pages/home_page.dart';
import 'pages/car_page.dart';
import 'pages/booking_page.dart';
import 'pages/revenue_page.dart';
// 1. Tambahkan import halaman Chat AI di sini
import 'pages/ai_chat_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    HomePage(),
    CarPage(),
    BookingPage(),
    RevenuePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(
        selectedIndex: selectedIndex,
        onTap: (index) {
          setState(() => selectedIndex = index);
          Navigator.pop(context);
        },
      ),
      appBar: AppBar(
        title: const Text("Admin Dashboard"),
        backgroundColor: Colors.black,
        elevation: 0,
        // 2. Tambahkan tombol Chat AI di bagian actions
        actions: [
          IconButton(
            icon: const Icon(Icons.smart_toy, color: Colors.white),
            onPressed: () {
              // Navigasi ke halaman Chat AI
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AIChatPage()),
              );
            },
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Color(0xFF0F2027)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: pages[selectedIndex],
      ),
    );
  }
}
