import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  static Future<Map<String, dynamic>> getDashboardData() async {
    final bookings = await FirebaseFirestore.instance
        .collection('bookings')
        .get();

    final cars = await FirebaseFirestore.instance.collection('cars').get();

    int totalBooking = bookings.docs.length;
    int totalCars = cars.docs.length;

    int pending = bookings.docs.where((e) => e['status'] == 'Pending').length;

    return {
      "totalBooking": totalBooking,
      "totalCars": totalCars,
      "pendingBooking": pending,
    };
  }
}
