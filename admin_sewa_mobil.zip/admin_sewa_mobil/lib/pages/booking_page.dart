import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class BookingPage extends StatelessWidget {
  const BookingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          "Manajemen Booking",
          style: TextStyle(color: Colors.cyanAccent),
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('bookings')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final bookings = snapshot.data!.docs;

          if (bookings.isEmpty) {
            return const Center(
              child: Text(
                "Belum ada pesanan",
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: bookings.length,
            itemBuilder: (context, index) {
              final booking = bookings[index].data() as Map<String, dynamic>;
              final docId = bookings[index].id;

              return _bookingCard(context, booking, docId);
            },
          );
        },
      ),
    );
  }

  Widget _bookingCard(
    BuildContext context,
    Map<String, dynamic> booking,
    String docId,
  ) {
    final formatter = DateFormat('dd MMM yyyy');

    final startDate = (booking['startDate'] as Timestamp).toDate();
    final endDate = (booking['endDate'] as Timestamp).toDate();

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// Header
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  booking['carImage'],
                  width: 90,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      booking['carName'],
                      style: const TextStyle(
                        color: Colors.cyanAccent,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    _statusBadge(booking['status']),
                  ],
                ),
              ),
            ],
          ),

          const Divider(color: Colors.white24, height: 24),

          _infoRow("Penyewa", booking['customerName']),
          _infoRow("Telepon", booking['customerPhone'].toString()),
          _infoRow(
            "Tanggal",
            "${formatter.format(startDate)} → ${formatter.format(endDate)}",
          ),
          _infoRow(
            "Total",
            "Rp ${NumberFormat('#,###').format(booking['totalPrice'])}",
          ),

          const SizedBox(height: 12),

          _actionButtons(context, booking['status'], docId),
        ],
      ),
    );
  }

  /// =======================
  /// STATUS BADGE
  /// =======================
  Widget _statusBadge(String status) {
    Color color;

    switch (status) {
      case "Pending":
        color = Colors.orange;
        break;
      case "Disewa":
        color = Colors.blue;
        break;
      case "Selesai":
        color = Colors.green;
        break;
      default:
        color = Colors.red;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Text(
        status,
        style: TextStyle(color: color, fontWeight: FontWeight.bold),
      ),
    );
  }

  /// =======================
  /// INFO ROW
  /// =======================
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(label, style: const TextStyle(color: Colors.white54)),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  /// =======================
  /// ACTION BUTTONS
  /// =======================
  Widget _actionButtons(BuildContext context, String status, String docId) {
    return Row(
      children: [
        if (status == "Pending")
          _actionBtn(
            "Konfirmasi",
            Colors.blue,
            () => _updateStatus(docId, "Disewa"),
          ),

        if (status == "Disewa")
          _actionBtn(
            "Selesaikan",
            Colors.green,
            () => _updateStatus(docId, "Selesai"),
          ),

        const Spacer(),

        if (status != "Selesai")
          _actionBtn(
            "Batalkan",
            Colors.red,
            () => _updateStatus(docId, "Dibatalkan"),
          ),
      ],
    );
  }

  Widget _actionBtn(String title, Color color, VoidCallback onTap) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(title),
    );
  }

  /// =======================
  /// UPDATE STATUS
  /// =======================
  void _updateStatus(String docId, String status) {
    FirebaseFirestore.instance.collection('bookings').doc(docId).update({
      "status": status,
    });
  }
}
