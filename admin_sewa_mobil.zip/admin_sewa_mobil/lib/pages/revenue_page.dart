import 'package:flutter/material.dart';

class RevenuePage extends StatelessWidget {
  const RevenuePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          _HeaderRevenue(),
          SizedBox(height: 20),
          _IncomeSummaryCard(),
          SizedBox(height: 20),
          _CarUsageReportCard(),
          SizedBox(height: 20),
          _MonthlyYearlyReportCard(),
        ],
      ),
    );
  }
}

/* ================= HEADER ================= */
class _HeaderRevenue extends StatelessWidget {
  const _HeaderRevenue();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text(
          "Reports",
          style: TextStyle(
            color: Colors.cyanAccent,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 6),
        Text(
          "Ringkasan pendapatan dan laporan penggunaan mobil",
          style: TextStyle(color: Colors.white54),
        ),
      ],
    );
  }
}

/* ================= INCOME ================= */
class _IncomeSummaryCard extends StatelessWidget {
  const _IncomeSummaryCard();

  @override
  Widget build(BuildContext context) {
    return _card(
      title: "💰 Ringkasan Pendapatan",
      child: Row(
        children: const [
          _IncomeItem("Hari Ini", "Rp 2.500.000"),
          _IncomeItem("Bulan Ini", "Rp 45.000.000"),
          _IncomeItem("Tahun Ini", "Rp 520.000.000"),
        ],
      ),
    );
  }
}

class _IncomeItem extends StatelessWidget {
  final String title;
  final String value;

  const _IncomeItem(this.title, this.value);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(title, style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(
                color: Colors.cyanAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ================= CAR USAGE ================= */
class _CarUsageReportCard extends StatelessWidget {
  const _CarUsageReportCard();

  @override
  Widget build(BuildContext context) {
    return _card(
      title: "🚘 Laporan Penggunaan Mobil",
      child: Column(
        children: const [
          _ReportRow("Total Mobil", "24 Unit"),
          _ReportRow("Paling Sering Disewa", "Toyota Avanza"),
          _ReportRow("Paling Jarang Disewa", "Honda Brio"),
        ],
      ),
    );
  }
}

/* ================= MONTHLY ================= */
class _MonthlyYearlyReportCard extends StatelessWidget {
  const _MonthlyYearlyReportCard();

  @override
  Widget build(BuildContext context) {
    return _card(
      title: "📊 Laporan Bulanan / Tahunan",
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _ReportRow("Bulan Terbaik", "Desember"),
          const _ReportRow("Pendapatan Tertinggi", "Rp 78.000.000"),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _ExportButton(
                  "Export PDF",
                  Icons.picture_as_pdf,
                  Colors.redAccent,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _ExportButton(
                  "Export Excel",
                  Icons.table_chart,
                  Colors.greenAccent,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/* ================= HELPERS ================= */
Widget _card({required String title, required Widget child}) {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: Colors.grey[900],
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Colors.cyanAccent,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 14),
        child,
      ],
    ),
  );
}

class _ReportRow extends StatelessWidget {
  final String label;
  final String value;
  const _ReportRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: const TextStyle(color: Colors.white54)),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _ExportButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;

  const _ExportButton(this.title, this.icon, this.color);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () {},
      icon: Icon(icon, color: Colors.black),
      label: Text(
        title,
        style: const TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
        ),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
