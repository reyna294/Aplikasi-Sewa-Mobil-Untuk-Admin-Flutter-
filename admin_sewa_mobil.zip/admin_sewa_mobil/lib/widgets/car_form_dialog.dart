import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CarFormDialog extends StatefulWidget {
  final QueryDocumentSnapshot? carData;

  const CarFormDialog({super.key, this.carData});

  @override
  State<CarFormDialog> createState() => _CarFormDialogState();
}

class _CarFormDialogState extends State<CarFormDialog> {
  final nameController = TextEditingController();
  final imageController = TextEditingController();
  final priceController = TextEditingController();
  String status = "Ready";

  @override
  void initState() {
    super.initState();
    if (widget.carData != null) {
      nameController.text = widget.carData!['name'];
      imageController.text = widget.carData!['image'];
      priceController.text = widget.carData!['price'].toString();
      status = widget.carData!['status'];
    }
  }

  Future<void> saveData() async {
    final data = {
      "name": nameController.text,
      "image": imageController.text,
      "price": int.parse(priceController.text),
      "status": status,
      "createdAt": Timestamp.now(),
    };

    final cars = FirebaseFirestore.instance.collection('cars');

    if (widget.carData == null) {
      await cars.add(data);
    } else {
      await cars.doc(widget.carData!.id).update(data);
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black,
      title: Text(
        widget.carData == null ? "Tambah Mobil" : "Edit Mobil",
        style: const TextStyle(color: Colors.cyanAccent),
      ),
      content: SingleChildScrollView(
        child: Column(
          children: [
            _input(nameController, "Nama Mobil"),
            _input(imageController, "Link Foto Mobil"),
            _input(
              priceController,
              "Harga per Hari",
              keyboard: TextInputType.number,
            ),
            DropdownButtonFormField(
              value: status,
              dropdownColor: Colors.black,
              items: const [
                DropdownMenuItem(value: "Ready", child: Text("Ready")),
                DropdownMenuItem(value: "Disewa", child: Text("Disewa")),
                DropdownMenuItem(value: "Servis", child: Text("Servis")),
              ],
              onChanged: (value) => setState(() => status = value!),
              decoration: const InputDecoration(labelText: "Status"),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          child: const Text("Batal"),
          onPressed: () => Navigator.pop(context),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.cyanAccent,
            foregroundColor: Colors.black,
          ),
          child: const Text("Simpan"),
          onPressed: saveData,
        ),
      ],
    );
  }

  Widget _input(
    TextEditingController c,
    String label, {
    TextInputType keyboard = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        keyboardType: keyboard,
        decoration: InputDecoration(labelText: label),
      ),
    );
  }
}
